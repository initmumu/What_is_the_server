const express = require("express")
const mysql = require("mysql")
const bodyParser= require('body-parser')

const db_config = require("./db/db_conn")

const app = express()
const connection = mysql.createConnection(db_config)

const PORT = 3456

app.use(express.static('public'));
app.use(bodyParser.urlencoded({extended: true})) 
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html')
})

app.get('/post', (req, res) => {
    res.sendFile(__dirname + "/post.html")
})

app.post('/post', (req, res) => {
    // 구현
})

app.get('/retrieve', (req, res)=>{
    res.sendFile(__dirname+"/retrieve.html")
})

app.get('/api/retrieve', (req, res) => {
    // 구현
})

app.listen(PORT, () => {
    console.log(`Server starts on ${PORT}`)
})