module.exports = {
    host: '디비서버 주소',
    user: '유저명',
    password: '패스워드',
    database: '데이터베이스 이름'
}